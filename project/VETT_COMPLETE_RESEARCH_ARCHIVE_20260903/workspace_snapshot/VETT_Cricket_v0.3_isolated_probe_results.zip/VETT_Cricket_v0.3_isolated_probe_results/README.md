# VETT-Cricket Candidate v0.3 — High-audit checkpoint

This package is an executable construction checkpoint for the VETT-Cricket
text-to-table benchmark. It is mechanically validated, but it is not yet a
public benchmark release.

## Contents

- `schemas/`: canonical root, benchmark instance and cell-provenance schemas.
- `data/canonical_roots_217.jsonl`: 217 de-duplicated canonical candidates.
- `data/pilot_instances_80_candidate.jsonl`: 20 roots × V0–V3.
- `data/full_instances_868_candidate.jsonl`: all 217 roots × V0–V3 with release
  gating.
- `data/split_manifest.csv`: frozen 62/18/19 train/dev/test assignment for 99
  internally consistent roots; unresolved roots are marked `blocked`.
- `annotations/`: automatic V0 support proposals awaiting human adjudication.
- `generation/`: model roles, 36 pilot naturalization jobs and one
  current-model-authored calibration draft.
- `baselines/`: cricket-adapted T³, MapMake and Direct-CoT prompt contracts.
- `experiments/v0.3_dev_baseline/`: 54 gold-free dev inputs and 324 frozen
  method jobs covering six prompting configurations.
- `scripts/`: build, validation, scorer, mutation, diagnostic and release-gate
  tools.
- `validation/release_gate.json`: aggregate mechanical and scientific release
  decision.

## Current inventory

| Item | Count |
| --- | ---: |
| Canonical roots | 217 |
| Ready roots | 99 |
| Full V0–V3 instances | 868 |
| V1–V3 release candidates | 297 |
| V0 support-annotation candidates | 99 |
| Blocked instances | 472 |
| Scored cells in V1–V3 | 125,070 |
| V3 derived cells | 8,007 |

## Rebuild

```bash
python scripts/build_candidate_dataset.py \
  --source /path/to/cricket_220_extracted \
  --audit-csv /path/to/per_match_audit.csv \
  --pilot-csv /path/to/pilot_20_manifest.csv \
  --audit-module-dir /path/to/cricket_220_audit_v1 \
  --curation-overrides data/curation_overrides_v0.3.json \
  --output data
```

## Difficulty design

- V1 is evidence-complete and fixed-schema.
- V2 adds provisional, corrected and stale claims, including three cross-table
  revision chains per match.
- V3 distributes evidence across sources, requires eight executable derivation
  operators, hides the schema, shuffles arrival order and interleaves a
  same-split, different-venue match dossier selected for player-name overlap.
- Every V3 gold span is checked to ensure that it never points into the
  distractor dossier.

## High-intensity checks

- 536,634 construction/provenance checks: PASS.
- 11,494 cricket arithmetic and cross-table checks: PASS.
- JSON Schema validation over 217 roots, 868 instances and 131,262 provenance
  objects: PASS.
- 1,586 leakage, duplicate and scope checks: PASS with zero warnings.
- 48 deliberate scorer mutations: PASS.
- Private-ID and ID-free semantic oracles over 125,070 cells: 100% cell and
  table exact.
- Five core artifacts from a clean rebuild: byte-identical.
- Baseline blind-package and model-runner self-tests: PASS.
- Six-condition isolated same-model probe over three dev roots: completed;
  strict-schema and semantic-equivalence scores are both retained.

## Release warning

The aggregate gate reports `mechanical_status: PASS` and
`public_release_status: NOT_READY_FOR_PUBLIC_RELEASE`. The scientific blockers
are surface-form repetition, unapproved naturalization, pending human and
unique-solution review, pending independent inverse extraction, pending V0
support adjudication and absent real T³/MapMake/Direct-CoT runs.

`RELEASE_CANDIDATE` means mechanically valid candidate, not human-verified
public gold. Diagnostic oracle ablations are not measurements of T³, MapMake
or Direct-CoT.

## Isolated probe result

After cricket-semantic normalization, cell error ranges from 0.78% to 34.55%;
all but paper-style MapMake have 0% table exact, while paper-style MapMake has
33.33%. Strict-schema cell error ranges from 20.16% to 41.14%. These results
show that the current ladder strongly tests schema realization but remains too
easy for several methods at the fact level. They are three-root development
calibration results, not paper baseline estimates.

The baseline runner requires `VETT_LLM_BASE_URL`, `VETT_LLM_API_KEY` and
`VETT_LLM_MODEL`, or the equivalent command-line arguments. Credentials are
never written into run artifacts. The paper's main T³ code-generation variant
remains blocked until a reviewed isolated execution sandbox is available.
