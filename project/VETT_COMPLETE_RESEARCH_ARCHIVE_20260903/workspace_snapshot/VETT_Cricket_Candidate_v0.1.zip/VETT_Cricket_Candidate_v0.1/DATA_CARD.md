# VETT-Cricket Candidate v0.1 — Data Card

## Dataset purpose

VETT-Cricket evaluates text-to-table systems under evidence sufficiency,
cross-document integration, cricket arithmetic, source authority, revision
chains and latent multi-table schemas.

## Source roots

- 220 uploaded match packages were audited.
- 3 exact duplicate packages were excluded.
- 217 candidate roots remain.
- Source text and scorecards are anonymized or redesigned; external match truth
  and licensing still require owner confirmation.

## Candidate status

This is a research construction checkpoint, not a public benchmark release.

| Item | Count |
| --- | ---: |
| Canonical candidate roots | 217 |
| Pilot roots | 20 |
| Full V0–V3 instances | 868 |
| Full V1–V3 release candidates | 312 |
| Full V0 instances awaiting support annotation | 104 |
| Full blocked instances | 452 |
| Full candidate scored cells in V1–V3 | 131,412 |
| V3 derived cells | 8,412 |
| Pilot V0–V3 instances | 80 |
| Pilot V1–V3 release candidates | 36 |

Root states:

| Root state | Count |
| --- | ---: |
| `READY_FOR_GENERATED_VIEWS` | 104 |
| `NEEDS_BALL_ACCOUNTING` | 46 |
| `BLOCKED_SCORECARD_CONFLICT` | 64 |
| `BLOCKED_CONSTRUCTION_LEAK` | 3 |

## Views

- V0: natural report with supported-cell target; gold pending annotation.
- V1: evidence-complete fixed-schema official bulletins.
- V2: V1 plus provisional, official correction and stale repost.
- V3: distributed multi-source evidence, latent schema, revision chain and
  executable global derivations, plus a same-split second-match dossier. The
  target is uniquely specified by venue and teams.

The 104 ready roots have a frozen 64/20/20 train/dev/test split. Distractor
selection is restricted to the target root's split to prevent cross-split text
leakage.

## Mechanically verified properties

- 560,922 full-candidate checks passed with zero failures.
- All 131,412 scored cells are covered by direct evidence or executable
  derivation.
- All 8,412 V3 derivations execute to their canonical value.
- All 35,496 checked V3 evidence references point to the target dossier, never
  the distractor dossier.
- Oracle predictions obtain 100% cell accuracy and 100% table exact match.

## Controlled diagnostic ablations

These are oracle ablations, not model baselines:

| Diagnostic | V3 cell error | V3 table exact |
| --- | ---: | ---: |
| Omit every derived cell | 19.20% | 0% |
| Keep stale rather than corrected value | 0.24% | 0% |
| Select the wrong match dossier | 100% | 0% |

The stale-value result shows why cell accuracy alone is inadequate: one wrong
revision per match barely moves micro cell accuracy but destroys exact table
reconstruction. The benchmark therefore reports both cell and table metrics.

## Gold policy

Model-generated values are prohibited. Canonical values come from an
internally validated root, then require human or expert verification before
release. Blocked roots have zero scored cells.

## Known limitations

1. External official match sources were not available in the uploaded package.
2. Current V1–V3 text is a deterministic evidence-complete draft; model-assisted
   naturalization and human language review remain pending.
3. Current domain is cricket; broader claims require transfer experiments or a
   cross-domain extension.
4. V0 automatic support proposals are not gold.
5. Source licensing and long-term distribution rights must be documented
   before publication.
6. No official T³, Map&Make or Direct-CoT run has been executed in this
   workspace. Their error rates remain an empirical question.

## Responsible use

The dataset is intended for information extraction, table generation,
reasoning and evaluation research. It should not be presented as an official
record of real matches unless external provenance is independently verified.
