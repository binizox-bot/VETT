# Model-in-the-loop batch 1

## Role

The current conversational model acted as:

1. adversarial design critic;
2. revision-density planner;
3. verbalizer for one calibration instance;
4. reviewer of mechanical validation results.

It did not act as an independent inverse extractor. Therefore no instance was
upgraded to `HUMAN_VERIFIED`.

## Critic findings

- V1 still exposes repeated scorecard templates.
- V2 and V3 originally revised only one cell per match. This was enough to
  destroy table exact match but too sparse for useful field-level diagnosis.
- V3 combines genuine integration demands with strong surface repetition.
- Reusing deterministic dossier language makes a construction-style classifier
  plausible, even when the underlying facts and evidence are correct.
- A separate model family or endpoint is still needed for independent inverse
  extraction.

## Changes executed

- Each V2/V3 match now carries three revision chains drawn from batting,
  bowling and innings summary fields.
- Across the full candidate this yields 624 independently validated revised
  cells and 1,872 provisional/valid/stale claims.
- The full validator now performs 563,626 checks with zero failures.
- A template fingerprint audit was added.
- `match_0009.V2` received current-model-authored natural prose for its
  provisional feed, official correction and stale repost.
- Its evidence spans and hashes were recomputed and validated.

## Fingerprint audit

Before full naturalization:

| View | Unique skeleton ratio | Repeated sentence rate |
| --- | ---: | ---: |
| V1 | 71.12% | 36.00% |
| V2 | 63.21% | 43.14% |
| V3 | 22.88% | 92.28% |

V3 is inflated by intentional reuse of a target dossier as another instance's
distractor, but the result still fails the intended anti-template release gate.

## Decision

- Mechanical validity: PASS.
- Revision-density calibration: PASS.
- Single model-authored verbalization sample: PASS mechanically.
- Independent inverse extraction: PENDING.
- Human cricket-language review: PENDING.
- Full language naturalization: FAIL/PENDING.

The batch is useful construction progress, not a public-release certificate.
