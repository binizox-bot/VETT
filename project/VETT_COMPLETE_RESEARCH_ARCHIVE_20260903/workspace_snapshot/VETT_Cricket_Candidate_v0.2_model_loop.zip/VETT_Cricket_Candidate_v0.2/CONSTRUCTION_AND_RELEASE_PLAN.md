# VETT-Cricket 完整构造与发布路线

## 当前已经完成的部分

1. 对 220 场原始包完成结构审计并去除 3 组重复，保留 217 个事实根。
2. 将原始表统一为 canonical root、稳定 cell ID、事件记录和可追踪哈希。
3. 为每个事实根生成 V0–V3 四种视图，共 868 个候选实例。
4. 仅对 104 个内部一致的事实根开放 V1–V3，共 312 个
   `RELEASE_CANDIDATE`；其余实例保持 blocked，不伪造 gold。
5. 构造固定的 64/20/20 train/dev/test 划分。
6. V3 已包含多来源、版本冲突、乱序、隐式 schema、八类可执行推导和
   同 split 的跨比赛干扰文档。
7. 完成 563,626 项机械校验，当前失败数为 0；oracle 对 131,412 个评分
   单元达到 100%。
8. 已生成 36 个 pilot 模型自然化任务，并提供 T³、Map&Make、Direct-CoT
   的统一运行协议。

## 仍然必须完成的发布门槛

### A. 事实根裁决

- 64 场 `BLOCKED_SCORECARD_CONFLICT`：由两名标注者独立定位冲突，再由
  板球专家裁决；不能用模型投票决定事实。
- 46 场 `NEEDS_BALL_ACCOUNTING`：逐局验证合法球数、overs 记法、总分、
  extras、投球 conceded runs、FOW 和 partnerships。
- 3 场 `BLOCKED_CONSTRUCTION_LEAK`：重写输入文本并重新做泄漏扫描。
- 所有修改必须形成版本记录，旧 gold 不覆盖，新版本必须重新跑全套校验。

### B. V0 支持性标注

- 当前 104 场 eligible V0 共得到 6,521 个 direct 候选和 37,283 个
  table-only 候选。
- 两名标注者独立判断 `DIRECT / DERIVED / TABLE_ONLY / AMBIGUOUS`，并标
  exact span。
- disagreement 由第三人裁决；V0 只评分文本支持或唯一可推导的单元，
  不能把表中存在但文本未给出的值当成 gold。
- 在至少 10% 双重抽检样本上报告 span F1、支持类型一致率和 Krippendorff
  α；未达到预注册门槛时继续返工。

### C. 模型辅助自然化

对 pilot 的 36 个 job 先执行以下独立角色：

1. discourse planner 只规划文档和事实分配；
2. verbalizer 只改写表达，不得更改事实；
3. inverse extractor 在独立上下文中只看生成文本并反抽事实；
4. adversarial critic 查找歧义、模板指纹、泄漏和多解；
5. symbolic validator 重新核验 span、公式、版本和作用域；
6. 人类板球语言审核后才能把 `AUTO_CANDIDATE` 改为
   `HUMAN_VERIFIED`。

禁止同一次模型回答同时承担生成和验收。模型、prompt 哈希、温度、
上下文长度和日期必须记录。pilot 通过后才扩展到全部 312 个候选。

### D. 去模板化与反构造痕迹

- 至少准备新闻报道、赛后分析、直播更新、官方更正、统计笔记、简短公告
  等多个文体池。
- 文体、句法、段落长度、事实顺序、来源数量和数字表达分别采样；不得用
  match ID 或难度标签决定固定模板。
- 训练一个只识别“自然样本/构造样本”的诊断分类器。若其在 unseen
  split 上显著高于随机，人工分析其线索并返工；该分类器不能用于选择
  gold。
- 对同一事实根只允许一个视图进入盲测主榜，其他视图用于受控
  robustness 对比，避免同根记忆抬高结果。

### E. 基线与现代模型评测

- 同一 backbone、温度、上下文和输出预算下运行 T³、Map&Make、
  Direct-CoT；同时加入 direct prompting、强指令模型和至少一个开放权重
  模型。
- T³ 的集成阶段只能读取 tuple；Map&Make 的生成阶段只能读取 atoms 和
  schema。不得让中间阶段偷看原文。
- 报告 V1→V2、V2→V3 的性能下降，并做以下消融：
  source scope、version、arrival order、derivation、latent schema、
  distractor。
- 指标至少包括 cell accuracy/error、micro/macro F1、table exact、
  schema F1、row alignment、hallucination、omission、revision accuracy、
  derived-cell accuracy 和 target-scope accuracy。
- “错误率超过 60%”不能作为构造时强行追求的 gold 条件。正确做法是先
  冻结数据和验收规则，再盲跑方法；否则会被质疑为针对基线调题。

### F. 论文级有效性实验

- 人类上限：至少两名熟悉板球计分的人员完成分层样本，报告准确率和时间。
- 难度有效性：验证 V1、V2、V3 在模型和人类上的单调趋势。
- 归因有效性：每个 operator 的去除实验必须对应预期错误类型。
- 稳健性：更换模型家族、prompt 形式和解析器后，结论方向应保持。
- 污染检查：基于文本 n-gram、实体组合和哈希进行公开语料近重复检索。
- 发布 test 输入与评测器，test gold 保持私有或采用受控提交服务器。

## 建议的论文主张边界

当前版本可以主张“完成了可执行的候选构造管线，并证明 gold、证据和
难度算子在机械层面一致”。在完成人工裁决、模型自然化和盲基线运行之前，
不能主张“已形成最终公开 benchmark”，也不能声称 T³、Map&Make 或 CoT
达到某个真实错误率。
