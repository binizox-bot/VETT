# VETT-Cricket Candidate v0.2

This package implements the first executable construction checkpoint for the
VETT-Cricket benchmark.

## Contents

- `schemas/`: canonical root, benchmark instance and cell provenance schemas.
- `data/canonical_roots_217.jsonl`: 217 de-duplicated canonical candidates.
- `data/pilot_instances_80_candidate.jsonl`: 20 roots × V0–V3.
- `data/full_instances_868_candidate.jsonl`: all 217 roots × V0–V3, with
  release gating.
- `data/split_manifest.csv`: frozen 64/20/20 train/dev/test assignment for the
  104 internally consistent roots; unresolved roots are marked `blocked`.
- `annotations/v0_support_proposals.jsonl`: automatic proposals for human review.
- `annotations/v0_support_proposals_full.jsonl`: proposals for all 104 eligible
  V0 roots.
- `generation/`: model roles and naturalization protocol.
- `generation/pilot_model_jobs_36.jsonl`: private construction jobs for the 36
  mechanically valid pilot instances.
- `baselines/`: cricket-adapted T³, Map&Make and Direct-CoT prompt contracts.
- `scripts/`: build, support proposal, model-job, validation, diagnostic,
  oracle, summary and scoring tools.
- `validation/full_validation_report.json`: 563,626 checks, all passed.
- `validation/full_oracle_score.json`: scorer oracle at 100% cell and table
  accuracy over 131,412 scored cells.
- `validation/composition_summary.json`: view-level length, support and
  operator statistics.

## Rebuild

```bash
python scripts/build_candidate_dataset.py \
  --source /path/to/cricket_220_extracted \
  --audit-csv /path/to/per_match_audit.csv \
  --pilot-csv /path/to/pilot_20_manifest.csv \
  --audit-module-dir /path/to/cricket_220_audit_v1 \
  --output data
```

## Validate

```bash
python scripts/validate_candidate_dataset.py \
  --roots data/canonical_roots_217.jsonl \
  --instances data/full_instances_868_candidate.jsonl \
  --output validation/full_validation_report.json
```

## Difficulty design

- V1 is evidence-complete and fixed-schema.
- V2 adds provisional, corrected and stale claims.
- V2/V3 now carry three cross-table revision chains per match: batting,
  bowling and innings summary.
- V3 distributes evidence across source types, requires eight executable
  derivation operators, hides the schema, shuffles arrival order and interleaves
  a second same-split match dossier selected for player-name overlap.
- Every V3 gold span is checked to ensure that it never points into the
  distractor dossier.

## Important release warning

`RELEASE_CANDIDATE` means mechanically valid candidate. It does not mean
human-verified public gold. V0, blocked roots and deterministic draft prose must
not be included in final paper claims until the annotation, naturalization and
adjudication gates in `CONSTRUCTION_AND_RELEASE_PLAN.md` are complete. The
diagnostic oracle ablations are not T³, Map&Make or Direct-CoT results.

`generation/calibration_match_0009_V2_model_naturalized.jsonl` is the first
current-model-authored verbalization sample. It passes mechanical validation
but remains pending independent inverse extraction and human review.
