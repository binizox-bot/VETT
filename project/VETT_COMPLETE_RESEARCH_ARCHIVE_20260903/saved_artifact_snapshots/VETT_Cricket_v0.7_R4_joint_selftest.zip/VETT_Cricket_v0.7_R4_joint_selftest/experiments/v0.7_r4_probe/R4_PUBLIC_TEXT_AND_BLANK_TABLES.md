# R4 readable public package

Values are intentionally blank.

## match_0185.R4S

Resolve the accepted match state jointly. Two locally coherent event assignments may survive inside individual documents. Use delivery identity, explicit source authority, legal-ball state, dismissal ownership and cross-table conservation; do not repair requested rows independently.

### match_0185 continuous broadcast archive

[P01] The archive from Brookside Training Oval is less a conventional highlights reel than a stitched record of how the match was scored. Tidehaven chose to bat, and the first pictures are from the end-on camera while the television graphics computer was still taking its feed from a trainee's console. Harvey Lane defended the first legal ball from Noah Vance and lost his stumps to the next. A crowd microphone briefly obscured the umpire's signal, but both the paper book and the bowler-end counter identify the dismissal as delivery TV-001-B. Rohan Blake then walked in, and a delayed square-leg clip arrived before the live camera had caught up.

[P02] That delayed clip showed Blake and Miles Sharp crossing, and the trainee first treated the movement as a completed run. The umpire log attached the picture to TV-001-C, however, a ball already coded wide before either batter set off; the team event survives but no batter owns the movement. Sharp was bowled on the next legal delivery, TV-002-A. The paper book marks the side at one with two batters gone, while the television ribbon briefly carried a higher figure because it had both the wide and the running picture. The scorer did not issue a replacement total; she merely linked both pictures to the same delivery signature.

[P03] Nolan Reed joined Blake and spent his first few balls pinned behind the crease. Blake drove Vance through cover in the live feed, then worked separate deliveries into the leg side and behind point. A second cover-drive clip appeared during a drinks promo, with the same sightscreen attendant crossing the frame and the same deep fielder slipping as in the live shot. The archive editor labelled it REPLAY-A rather than a new ball. At the other end Nolan eventually completed one run. The partnership monitor was still provisional, because one tight-angle running clip had no visible umpire and another reverse angle lacked the broadcast clock.

[P04] Arlo Finch, keeping for Ridgefield, supplied the decisive identity clue from behind the stumps. His helmet-camera file carried the ball-change code used before the drinks promo, placing the tight-angle clip on TV-001-C, the wide already discussed, rather than in the Blake-Nolan stand. The reverse-angle picture was matched to Blake's behind-point single by the non-striker's distinctive bat tape and the same return throw. Those matches changed ownership and duplication status across the batter and partnership views without creating a new team event. The remaining Blake scoring pictures have separate delivery identifiers, while Nolan's completed run and the stand's lone extra are independently marked in the paper book.

[P05] The score ribbon next settled at eleven when Finch held Blake from Vance at 5.4. That caption is retained in the archive because its event time agrees with the umpire card, not because the later programme repeated it. Nolan and Caleb Frost then occupied the crease through a quiet passage. A leg-side delivery called wide was displayed twice, once live and once inside an analysis box, but the replay carries the same NV-05-W signature. Nolan was bowled at 7.3. The paper scorer's next-state line shows twelve at the fourth wicket, giving the later partnership material a clean boundary even though the television crawl had temporarily counted the analysis-box copy.

[P06] Caleb and Owen Marsh began with the surface looking slower by the minute. Owen's square drive was the only boundary in their stand, and a later clip shows him turning the strike over. That single was transmitted again after a camera reset; the archive clock, striker's glove adjustment and return path all match the original. Caleb's early push was initially entered as a batter run, but the umpire's coded card says the ball brushed his pad and that the completed run belongs in the leg-bye channel. That ruling is referenced by delivery AW-08-C; nowhere on the card does the official state either man's innings aggregate.

[P07] The next over contained a cluster that explains why the live graphics never looked stable. Arjun Wells sent a ball beyond Owen's reach, and the square-leg console created one wide event. A near-identical clip from the following over arrived with the old camera timestamp and was provisionally accepted as another. The central scorer later paired it with the first by ball serial and fielder position. In between, Owen tucked a genuinely different delivery behind square and crossed. Caleb found one scoring stroke of his own after the pad incident. A dead-ball scamper also appeared on the trainee card, although the bowler had broken the stumps before the batters moved.

[P08] The dead-ball entry could not be resolved from the pictures alone. The authoritative source was the umpire log, which records AW-11-D as dead when the striker withdrew; the broadcast's apparent run belongs to no team, batter or stand ledger. The legitimate leg-side single has a separate sound spike and delivery serial. Owen was subsequently bowled by Wells on the second legal ball of the fourteenth over. The preceding fixed point was Nolan's dismissal many paragraphs earlier. Between those boundaries the archive contains the pad reclassification, a duplicated wide clip, one cancelled scamper and several valid scoring events, so no single local caption defines the stand.

[P09] Dylan Pierce was bowled later in the same Wells spell without the team score moving. A stump-camera package then replayed both Owen's and Dylan's dismissals under new video filenames. The production rundown, rather than a score caption, ties those files back to AW-13-B and AW-14-E. Caleb survived into the sixteenth over, where an appeal struck him in front. A side-on archive asset from that passage also appeared to show Caleb taking another pad contact and completing a run; with its clock strip missing, the secondary console kept it as a plausible new leg-bye candidate. Its identity was deferred rather than decided beside the earlier pad ruling.

[P10] Theo Grant made a single before the next wicket sequence. The television crawl initially left Theo's catch in Wells's column, an understandable continuation after the earlier bowled and lbw decisions. The scorer's dismissal slip instead identifies Elias Grant as the bowler and Ben Cole as catcher; the over stamp EG-17-C matches the live commentary call. The score had reached thirty by then. The distinction matters twice: Elias owns that catch, and Wells does not. Later compilations replay Theo's dismissal adjacent to the Caleb lbw, but the two event signatures and two bowlers remain separate in the official reconciliation.

[P11] Arun Cole and Kian Stone then nudged the innings onward. Four extras occurred in their stand, although the source cards do not package them as one tidy announcement: two separate wide signals appear on Ben Cole's spell sheet, and a paired signal in Wells's return spell is supported by two distinct ball serials. Arun completed two batter runs across different overs, Kian one, and the stand closed when Wells bowled Arun at 19.1. An overnight edit placed one of Ben's wide clips beside the Wells pair, but the bowler-end cards preserve three distinct delivery identities across those two bowlers.

[P12] Vikram Holt was last in. A Wells delivery passed the bat and drew a wide signal before the legal sequence resumed. The delayed highlights strip later replayed that same miss after the wicket and gave it a fresh asset number; matching advertising-board movement and the ball-retrieval path show it is the original event. Vikram was bowled after two earlier legal balls in that over. That was Tidehaven's tenth completed dismissal. No batter run was made in the final stand, although the wide and its replay occupied two broadcast slots.

[P13] During the interval the scorers compared the extras channels rather than announcing a replacement innings line. Vance's sheet contains two separate occasions on which consecutive wide signals belong to distinct balls, while Elias's has none. The original AW-08-C ruling remains in the leg-bye channel, but the clockless side-on pad asset from the later spell is still quarantined pending a production match. A Wells overstep carries its own no-ball code, and the keeper audit found no untouched-ball bye. The batter-event ledger and these extras channels must reconcile with every wicket-state boundary rather than treating the provisional pad asset as decisive.

[P14] The wicket audit was conducted independently. Vance's credit lines were checked against the early dismissal signatures, and Nolan's stump-camera close-up was collapsed with NV-07-C rather than treated as another wicket. Wells's candidate lines were checked across the later dismissal slips, with Theo retained under Elias after the over-stamp review. No run-out, obstruction or retired-out event appears in the innings. A separate wicket-state card attaches twenty-four to Owen's dismissal. Thus the dismissed batters can be mapped to bowler credits without relying on the briefly incorrect scrolling columns.

[P15] Ridgefield's chase began under brighter light, but its feed was no cleaner. Owen Marsh's opening ball was called no-ball after Arlo Finch drove in the air and was caught. The front-on replay and the umpire card share OM-00-A, so the catch, the overstep and the running pictures are facets of one event, not separate deliveries. Finch remained at the crease. The broadcast then repeated the catch twice while analysts discussed the call. Neither replay has a legal-ball tick, and neither can create a dismissal, though the delivery's no-ball value remains in the team and bowler ledgers.

[P16] Finch responded with a cover boundary on a legal ball, and another four came through midwicket later in the over. Ben Cole struck a six during the opening stand. Owen also sent two balls beyond Finch's reach during the spell; the signals belong to different deliveries. When an attempted catch off Finch appeared between them, the synchronized heel frame showed Owen had not overstepped on that occasion and the ball was recorded as a legal scoring shot rather than another no-ball. A regional replay altered the clip order, so chronological position alone could not settle batter ownership.

[P17] Ben's wicket arrived near the end of Owen's second over. He drove a legal delivery toward Blake, who held it. The dismissal card carries OM-02-F, distinct from the opening no-ball catch of Finch, and later close-ups of Blake's hands retain the same code. The ground ribbon showed eighteen with one wicket down when the catch was confirmed. The opening partnership also contains the delivery extra from OM-00-A. Finch's opening contribution is not stated on any final batter graphic; it must agree with the wicket-state figure, Ben's accepted event set and that delivery extra.

[P18] Noah Vance joined Finch, and Arun Cole began the next over with a sequence of leg-side misses. The umpire card recognizes three different wide events before a legal dot; the television cut the first miss into both a live shot and a slow-motion insert. Another pair of misses later in the over have distinct ball serials despite looking nearly identical. A graphic operator also marked a heel-near-line delivery as a possible overstep. The ordinary broadcast angle cannot settle the call, and the temporary extras ribbon retains that candidate while the synchronized frame list is requested from the technical archive.

[P19] Finch drove one legal Arun ball through extra cover, then a replay of his earlier opening boundary appeared immediately afterward. The second clip has the old OM camera code and cannot be part of the new stand. Noah opened his account with a single, and later completed another. A running picture that seemed to give Finch one more was linked by shirt movement and the umpire's arm to Arun's final wide, so it remains a team extra rather than a batter run. The stand tracker was therefore carrying two locally plausible versions while the video identities were unresolved.

[P20] Caleb Frost took the ball for the closing over. His first broadcast slot showed an apparent legal delivery and a scrambled run, but the umpire card marks CF-04-A as an overstep. The run was completed from Finch's bat and the no-ball value also belongs to the innings, while the delivery does not advance the legal-ball counter. A later wide-looking replay was actually the earlier Arun event, recognizable from the bowler's sleeve and the east-stand shadow. Caleb's remaining deliveries were legal. Finch and Noah exchanged the strike without another dismissal.

[P21] With two legal balls of the fourth over completed, the paper book says Ridgefield had drawn level with Tidehaven's terminal run state. The broadcast ribbon was temporarily four higher because it had appended the replayed opening cover drive from P19. The archive controller removed that asset after matching its OM code, but issued no fresh score caption. On the next legal ball Finch completed the winning single. The ball counter therefore stops on the third legal delivery of that over, while the cancelled opening catch and Caleb's overstep had occupied broadcast time without advancing that counter.

[P22] The chase reconciliation was split among three desks. The legal-ball clerk places OM-02-F on the fifth counted delivery of Owen's second over, while the production desk links the later close-ups of Blake's hands to that same catch asset. Arun's wide signals remain on a separate sheet, and the unresolved heel frame is sent onward without a local ruling. A downstream ticker mixed several replay assets into its columns, so neither its wicket entry nor its extras entry is treated as authoritative. The desks retain event identifiers and postpone their final cross-ledger reconciliation.

[P23] The partnership desk retained its opening state from the earlier catch but did not close the record until the later legal-ball audit in P28. Inside that interval, Noah's two separate singles are supported by legal-ball ticks. Finch's valid contribution contains the extra-cover boundary, other distinct scoring shots and the winning single, but excludes the old opening replay and the run picture assigned to an Arun wide. The stand also inherits Arun's recognized wides and Caleb's no-ball. Two provisional stand cards remain plausible until those ownership decisions are combined with the start and end states.

[P24] A separate batter audit followed Finch across both stands. In the opening phase, the wicket-state figure must be partitioned among Ben's accepted scoring events, the opening delivery extra and Finch's legal shots; the cancelled catch contributes no dismissal or batter loss. Ben's crossed run is supported by its own ball serial despite appearing out of sequence in the regional package. In the later phase, Noah's two legal singles and the accepted extras are separated from Finch's shots. The opening cover replay cannot cross the partnership boundary merely because it was broadcast during the second stand. The two phase records share a player but not an event.

[P25] The archivist then compared team conservation in both innings. For Tidehaven, the accepted batter accounts sum to twenty-two: the non-target batters contribute no run from Lane, Sharp, Dylan or Vikram, one each from Nolan, Theo and Kian, two each from Caleb and Arun, with Blake and Owen determined by their corrected event sets. An interval signature audit also retains Owen's remaining earlier single as distinct from the two already discussed. For Ridgefield, Ben and Noah supply their accepted batter events, Finch supplies the disjoint phase records, and all other listed batters never appeared. The chase extras are exhausted by recognized wides and oversteps.

[P26] The partnership conservation sheet offers another view of Tidehaven without printing a final card. The first four stands move the wicket states from the opening dismissal through Nolan's wicket. The Caleb-Owen stand spans the fixed states in P05 and P14. Wells's own sheet preserves three paired wide occasions after the old camera duplicate is resolved. The production manifest now matches the clockless pad asset from P09 to AW-08-C by ball scuff, keeper crouch and return path, so it is a second view of the earlier event rather than a later team run. Arun's dismissal fixes the side on thirty-five, and every stand boundary remains tied to one dismissal event.

[P27] Legal-ball accounting supplies the last independent constraint on Tidehaven. Vance delivered six complete overs, Wells nine overs and three legal balls, Elias two complete overs, and Ben three. Wides and the Wells no-ball did not increase the legal count. The last wicket is attached to Wells's third legal ball after the twentieth over, consistent with the innings closure in P12. The television asset count is larger because it includes repeated wides and replayed wickets, but asset count is never substituted for balls faced or overs bowled.

[P28] Ridgefield's legal-ball account works similarly. Owen's two completed overs contain more broadcast slots than counted deliveries because the opening sequence includes an umpire-coded irregular ball. Arun delivered a complete over. Caleb's closing sequence begins with an uncounted overstep and is followed by three legal balls, and those logs confirm the terminal event described in P21. The technical asset total is larger than the ball counter, so the reconciliation depends on delivery identities rather than clip count.

[P29] The source hierarchy remained stable throughout the reconstruction. Umpire cards decide legality and extras class; the paper scorer decides batter and partnership ownership after consulting those cards; production manifests decide whether two video assets represent one delivery; the live television ribbon is only provisional. The synchronized heel sequence requested in P18 places Arun's back foot behind the line on AC-03-D, and the legal-ball clerk's continuous count accepts that frame match. Elsewhere, TV-001-C resolves Blake's apparent run and the AW-08-C media pair resolves Caleb's pad ownership. Their consequences propagate through several ledgers.

[P30] The match result itself provides a broad check rather than a shortcut. Ridgefield won with nine wickets standing after chasing one more than Tidehaven made. That statement fixes the relationship between the innings, but not the component values, because the archive still requires the legal-ball endpoint, the solitary valid chase dismissal and the removal of duplicated scoring footage. Likewise, Noah Vance's player-of-the-match citation does not state his bowling column; his credits must be recovered from the distinct early dismissal signatures and the Nolan replay match.

[P31] Before sealing the archive, the scorer ran one more collision check on similar-looking events. Blake's two cover clips were one shot shown twice, whereas Finch's cover and midwicket boundaries in the opening phase were distinct. The later close-ups of Ben's catch all retain OM-02-F and collapse into the live dismissal asset. Wells's wickets of Owen and Dylan had adjacent replay filenames yet separate over stamps. The clockless Caleb pad view, by contrast, carries the same ball scuff and keeper movement as AW-08-C. These identity decisions prevent both silent duplication and mistaken cancellation.

[P32] The retained record is therefore an event graph rather than a polished score announcement. Dismissal nodes establish nonlocal state boundaries; legality nodes govern extras, wicket credit and ball counts; ownership nodes partition team events among batters and partnerships; replay links collapse duplicate media assets. Tidehaven's fifth-wicket boundary and Ridgefield's sole wicket boundary connect the innings-level, batter, bowling and partnership views. A reader can reconstruct every requested scalar and the formatted terminal states from those links, but no final target cell is spoken as a standalone result in the commentary.

### late scorer-headset recovery

The recovered headset channel begins halfway through an argument about two mirror files made during Tidehaven's innings. The television ingest treated every new filename as a new occurrence, while the paper desk required a delivery signature, an umpire state and a batter transition before opening a scoring edge. Neither side reads out a replacement card. They refer instead to the early Blake packet, the Caleb-Owen interval and the wicket ownership queue as one linked reconciliation, because changing any one of those packets also changes the balance used to check the others.

The first mirror contains the movement seen while Blake and Sharp crossed. A wireless operator associates the visible crossing with Blake; the square-leg channel associates the same frame with the already registered wide. The two descriptions can each support a locally tidy opening card. Only the event headers distinguish them: the frame shares TV-001-C with the umpire-wide record, whereas Blake's later singles have separate ball-change markers. The reverse-angle cover clip is also in the mirror index, so accepting it as new would affect both Blake's personal stream and the team boundary before his catch.

A similar fork appears in the Caleb-Owen interval. One cache preserves the apparent run after Owen withdrew and treats the second wide picture as another delivery. The venue book keeps AW-11-D in the dead-ball channel and links the later wide picture to its earlier signal. The interval can be made to balance under either cache if its start boundary is copied from the same cache; it cannot be reconciled against the independently sealed wicket state and the innings-wide signatures under both. This is why the headset staff refuse to repair Owen, the stand and the extras sheet one row at a time.

The wicket ownership queue creates a third dependency. A production continuation places Theo's catch beside Wells, but the spell-transition header names Elias. Moving that edge affects Wells's bowling partition while the team dismissal remains. The clerk checks the early Vance signatures, the Wells terminal delivery and the Elias transition together, rather than accepting a compact bowler total from the television rundown. The replay filenames for Nolan, Owen and Dylan are mirror nodes and never create new fallen-batter transitions.

During the chase the two systems diverge again. One branch keeps the airborne Finch picture as Owen's dismissal and treats the later Ben catch as a replay; the other attaches the opening picture to the umpire's overstep and keeps OM-02-F as the live dismissal. Both branches contain one dramatic catch and can look plausible in isolation. The incoming-batter marker, the fifth counted delivery in Owen's second over and the no-ball card do not agree with the first branch when considered together.

The Finch ledger cannot be closed at that point because the downstream feed has also copied his opening cover boundary into the Noah partnership. A different late ball, CF-04-A, has an overstep marker and a completed run from Finch's bat. If the copied boundary is kept while the overstep packet is discarded, the broadcast reaches a locally plausible winning picture but disagrees with the paper legal-ball sequence. If the live packet is kept and the mirror edge is collapsed, batter ownership, no-ball class, partnership progression and the terminal chase state move together.

### event-registry closure note

The registry closure note defines authority without publishing target values. Umpire event states govern legality and extras class. Paper scoring governs batter and partnership ownership only after those event states are attached. Production captions and replay filenames may supply identity evidence but cannot create a delivery, wicket or run by themselves. A candidate state is rejected if one event signature is consumed twice or if a mirror node advances a wicket or legal-ball boundary.

For Tidehaven the closure test is performed on one connected component containing TV-001-C, AW-11-D, the Wells-Elias spell transition, the fifth-wicket boundary and the terminal legal-ball state. The accepted component must conserve the innings between batter and extras ledgers, preserve ten distinct dismissals, and place each bowler-credited wicket on a live delivery. Removing any one of those checks leaves both cache interpretations usable; applying all of them leaves one.

For Ridgefield the connected component contains the opening overstep, OM-02-F, the replayed Finch boundary, CF-04-A and the final counted delivery. It must preserve the opening-stand wicket boundary, the second-stand start, the accepted no-ball identities and the target relationship to Tidehaven. The winning packet cannot be chosen independently of Finch's innings line or Owen's bowling line. The final signature set is signed, but no compact score row is transmitted on this channel.

| Innings | Table | Row | Column | Value |
| --- | --- | --- | --- | --- |
| I1 | Batting | Rohan Blake | R |  |
| I1 | Batting | Owen Marsh | R |  |
| I2 | Batting | Arlo Finch (wk) | R |  |
| I2 | Batting | Ben Cole | R |  |
| I1 | Bowling | Noah Vance | W |  |
| I1 | Bowling | Arjun Wells | W |  |
| I2 | Bowling | Owen Marsh | W |  |
| I1 | Innings Summary | Wides | Value |  |
| I1 | Innings Summary | Leg Byes | Value |  |
| I2 | Innings Summary | No Balls | Value |  |
| I1 | Partnerships | Caleb Frost & Owen Marsh | Runs |  |
| I2 | Partnerships | Noah Vance & Arlo Finch | Runs |  |

## match_0185.R4C

Resolve the accepted match state jointly. Two locally coherent event assignments may survive inside individual documents. Use delivery identity, explicit source authority, legal-ball state, dismissal ownership and cross-table conservation; do not repair requested rows independently.

| Innings | Table | Row | Column | Value |
| --- | --- | --- | --- | --- |
| I1 | Innings Summary | Total | Value |  |
| I2 | Innings Summary | Total | Value |  |
| I1 | Fall of Wickets | 5 | At |  |
| I2 | Fall of Wickets | 1 | At |  |

## match_0106.R4S

Resolve the accepted match state jointly. Two locally coherent event assignments may survive inside individual documents. Use delivery identity, explicit source authority, legal-ball state, dismissal ownership and cross-table conservation; do not repair requested rows independently.

### match_0106 continuous broadcast archive

Brookhaven’s archive begins before the first ball, with Coral Bay choosing to field and three record systems open beneath the commentary box. The television strip is fastest but often anticipates decisions; the venue board follows the umpires’ signals; the scorer’s paper book becomes authoritative once an event signature has been matched. None of the three is treated as complete by itself. The radio log has a fourth role: it preserves who was at which end and when a replay was introduced, but its casual numerical remarks never overrule an umpire card or a signed over sheet. This division of authority matters because the same pictures repeatedly return after play has moved on, often several overs later too.

Sienna Park starts to Elena Cross with Mira Vale at the other end. A pad deflection in the opening over brings a raised arm from square leg, but the camera cuts away before the scorer can see whether the signal is for a leg-bye or merely the completion of the ball. Television places the run beside Elena while the paper entry remains ringed.

Elena then drives through cover and turns several singles. The broadcast does not publish her personal tally. When Aila Rowan takes over, the opener is beaten at 3.6 and the bails come away. The ground partnership ribbon closes the association at eighteen, yet its division among Elena, Mira and extras is still provisional because the ringed opening-over delivery has not been classified.

The stump-camera picture returns twice while Tara Quinn walks in. Both clips carry the same north-end camera code, the same 3.6 timestamp and the same incoming batter marker. The television operator briefly flashes another wicket icon, but the scorer binds the two pictures to Elena’s one dismissal rather than treating the second angle as new play.

A radio analyst later reconstructs Mira’s opening spell at the crease from the running log. Her bat supplied three during the first association, and she faced no scoring delivery after Elena’s dismissal before Tara settled. The analyst does not know how the ringed pad event will be classified and therefore declines to infer Elena’s share.

Tara’s short stay has a different rhythm. She supplies seven, Mira two, and the interval includes two runs outside either bat. At 5.5 Aila finds the edge and Maris Vale holds the catch. The live event header bears the west-end identifier W055, distinguishing it from the earlier broken-stump event E036 despite a later highlights package placing them side by side.

During that highlights package the gallery first shows E036 from behind the arm, then W055 from square of the wicket, then E036 once more. Aila is credited only when a delivery header and an incoming-batter transition agree. The repeated Elena clip has no such transition, while Tara’s catch brings Rowan Hayes to the middle.

The innings audit desk separates the opening association by event signature. Two byes and two west-end wides are already signed inside that interval, while the ringed pad event remains outside all certified classes. On the innings-wide leg-bye register, two later north-end cards, LB22 and LB51, are already valid. The no-ball page has a matching video pair under review. No aggregate is announced.

Mira and Rowan move the score through a compact third association. Rowan’s bat supplies four, Mira’s three, and three are detached from the batters. Nia Brooke wins an lbw against Mira at 7.5. A stale production template labels the delivery with Aila’s name, even though Nia is visible completing her follow-through from the south end.

The ground desk refuses to decide the bowling owner from the lower-third alone. It records the event signature S075, the striker Mira, the pad decision and the incoming captain Nora Finch. Several overs later the end log will identify who delivered S075. Until then, Aila’s television analysis and Nia’s paper analysis remain locally plausible.

Rowan and Nora begin from the third-wicket boundary, whose team state is preserved in the fall clerk’s sealed line rather than read aloud. Rowan’s eventual contribution within this long stand is one more than sixteen. Nora’s working contribution is shown only on an internal monitor, and the interval’s non-batter component is kept by a separate assistant.

A no-ball sequence interrupts the partnership. Television replays the free-hit setup using the same frame twice and its ingestion service creates two worksheet rows. One row has the live event signature; the other lacks a new legal-ball transition. The no-ball clerk postpones any category decision until the over log returns from the umpire liaison.

Nora drives, cuts and runs hard, while Rowan increasingly turns the strike over. The partnership ribbon on television rises, but a one-run discrepancy opens between it and the paper component ledger. The discrepancy could belong either to Nora or to the illegal-delivery class, so neither source can settle the stand by itself.

At 15.3 Celeste Reed beats Rowan and hits the stumps. The television wicket light changes before its team-score line has caught up. The paper book closes the Rowan–Nora interval at this event signature, and Lena Moss enters. The fall clerk records the legal-ball marker separately from Rowan’s ordinal position.

The partnership assistant’s working non-batter entry for Rowan and Nora stands at eleven. Nora’s personal component simultaneously stands at thirty. Those two working entries share the disputed no-ball frame; both cannot survive once its identity is resolved. Rowan’s bat component, recorded much earlier, is not under review.

Lena and Nora run a brisk association. Lena supplies four, Nora six, and four sit outside the bat. Emilia Shaw breaks the stumps as Lena attempts a second. The batting and fall ledgers accept a run out, but an automated bowling graphic places a mark beside Celeste because she delivered the previous wicket-taking ball.

Production asks whether correcting the bowling graphic would also undo Lena’s dismissal. The scorer explains only the rule: a run out changes the team-wicket, batter and partnership ledgers, but gives no wicket to the current bowler. She points to Lena’s event identifier without reading Celeste’s eventual analysis.

The wide clerk closes the first innings class at eighteen. Four no-ball cards already carry distinct legal-transition signatures, while the matching video pair remains quarantined on a separate page. A separate mid-innings umpire card, LB143, has entered the leg-bye register; the clerk still waits for the square-leg signal from the opening passage. The category sheets are intentionally separate, leaving more than one plausible extras aggregate at this stage.

Jade Sinclair faces two balls with neither batter scoring and with no delivery outside the bat. Celeste bowls Jade. During the walk to the middle for Pippa Lane, the gallery repeats Rowan’s broken stumps beneath a generic Reed strikes caption. The batter transition and event code show that the old Rowan clip is not another Celeste delivery.

Pippa supplies six in her stand with Nora, Nora supplies two, and one belongs to neither batter. Nia bowls Pippa at 18.5. Nora’s innings now spans five completed associations, but the disputed component beside Rowan has not been incorporated into any public personal figure.

The archive then receives the delayed square-leg card from the opening over. Its event signature matches the ringed pad deflection rather than Elena’s cover drive. The signal is a leg-bye. This preserves the opening partnership and team ledgers while moving that run from the provisional batter stream into the appropriate extras class.

Because Mira’s share had been fixed on the radio log and Elena’s innings ended at the opening boundary, the scorer can now reconcile Elena across the partnership, batter and event-class ledgers. The relevant components remain in their original, widely separated archive passages, and no commentator gathers them or states the resulting batter figure.

Ivy Stone joins Nora. Ivy’s bat supplies five, Nora’s four, and one is outside the bat before Bella Marsh catches Nora from Celeste at 19.5. A replay of Nora’s earlier boundary appears after the catch, but the shared frame fingerprint and the closed personal ledger prevent that shot from becoming a second scoring event.

The no-ball clerk receives the over log. The worksheet row without a legal-ball transition is the duplicated picture, while the row bearing the live signature remains. The independently signed cards are kept on their earlier page. Of the matching pair, the clerk retains the row bearing the live signature and strikes through its transitionless twin, without returning to the earlier card list or reading a category count or the innings extras aggregate.

The same identity decision propagates to the long partnership. The run represented twice in the video feed belongs outside Nora’s bat. Her Rowan-stand component is therefore the working thirty with that disputed item removed, while the partnership assistant’s working eleven recognizes the same item on the non-batter side. Neither revised component is announced as a final table value.

At the other desk, the end log for S075 returns. It identifies Nia as the bowler of Mira’s lbw, so Aila’s provisional production mark for that event is void. The event itself remains a team wicket. The decision changes bowling ownership without changing the fall boundary or Mira’s batting dismissal.

Ivy and Clara Bell take two from the last ball, one from Ivy’s bat and one outside it. The innings closes after twenty overs. The venue screen gives only a victory-context graphic later in the evening; it never displays the full innings total in scorecard format during this archive segment.

The scorers begin their interval reconciliation. The batter ledger contains Elena’s inferred opening result, Mira’s eight, Tara’s seven, Rowan’s twenty-one, Nora’s distributed result, Lena’s four, Jade’s zero, Pippa’s six and Ivy’s six. Clara contributes none. These entries are checked against the four extras classes and the closed team ledger, but the sum is not spoken.

The delayed opening card is filed by its own event signature rather than merged into a verbal category summary. The no-ball page retains only events backed by legal transitions, while the bye and wide sheets remain in their separate folders. A second scorer confirms that the four classes are non-overlapping and exhaustive, which removes the last locally plausible alternative ledger without reciting any component count.

The bowling clerk reconciles delivered dismissals against the team-wicket book and the run-out rule. Every accepted credit must point to a distinct live delivery signature elsewhere in the archive; repeated stump clips and the false S075 attribution remain only as superseded audit entries. She signs the reconciliation without enumerating any bowler’s completed row.

Coral Bay’s chase begins with Jade bowling to Aila. At 0.4 the stumps are disturbed. One wide with signature CW004 has occurred in the opening association, while neither batter has scored from the bat. The gallery keeps the dismissal picture on screen as Nia arrives, so the incoming-batter marker rather than the visual cut establishes the event boundary.

Nia is lbw on the next legal ball. The delivery bears a new signature despite following immediately after Aila’s dismissal. A replay of Aila’s stumps appears while the review is explained; it retains the earlier timestamp and does not carry another batter transition. Jade’s wicket ledger must distinguish this new pad event from the repeated stump event.

Maris Vale and Emilia Shaw attempt to settle. Emilia supplies one, Maris two, and a leg-bye sits outside the bat before Jade bowls Maris at 3.6. Later, a generic Sinclair strikes caption is placed over the old Aila clip, but the event archive links the captioned footage back to the opening delivery rather than to another live dismissal.

Lara Holt joins Emilia. Each batter supplies one and their interval has no extras. Nora catches Lara from Tara Quinn at 6.2. A live blog briefly carries Jade’s generic caption beside the paragraph, yet the delivery header, bowler’s end and catcher sequence all identify Tara as the wicket owner.

Sienna Park becomes Emilia’s longest partner. Sienna’s bat contributes four. Emilia’s provisional component on television rises to ten, while an interval assistant opens a non-batter line at five. Two distinct wide cards, CW071 and CW083, are already accepted inside the association. Both component feeds may also have inherited another wide image from before the settled stand boundary.

A timeout sends the screen through three images: Sienna defending, Aila’s opening dismissal, and Sienna again. Jade is now at cover, not bowling. The unchanged Aila event signature and the absence of an incoming batter show that the middle image is archival. The chase wicket ledger remains on its live sequence. Away from the replay monitor, the over clerk files live wide cards CW096 and CW111 under Sienna’s batting interval; neither shares the inherited image’s timestamp.

Ivy Stone bowls Sienna at 12.1. This event closes the fifth chase association, but the television ribbon is one run ahead of the paper components. The scorer will not choose between Emilia’s batter feed and the interval extras feed until the boundary carry can be assigned.

Two overs later the over-transition log identifies the carried wide as belonging inside the Sienna association but outside Emilia’s bat. Emilia’s working component is the provisional ten without that item; the assistant’s non-batter line is the provisional five without an inherited duplicate of the same event. Sienna’s four remains untouched.

Faye Turner then faces two balls. Neither Faye nor Emilia scores and no extra occurs before Ivy bowls Faye. A replay of Sienna’s dismissal fills the walk-in interval, but Faye’s incoming and outgoing markers make clear that live play has advanced beyond the archival picture.

Bella Marsh also contributes nothing, as does Emilia in that short stand. One wide occurs before Ivy bowls Bella at 12.6. The repeated Sienna celebration is shown again between deliveries. It retains Sienna’s identifier, while Bella’s wicket carries a different event signature and a new incoming batter.

Only after Bella leaves does the interval clerk align the Sienna boundary provisionally. The component ledger contains Sienna’s four, Emilia’s revised share and the revised non-batter component, but the row remains unsigned until the wide archive completes its event-identity audit. No ribbon presents a final runs value.

Celeste Reed and Emilia share the next passage. Celeste supplies one, Emilia one and one wide occurs before Rowan catches Celeste from Tara at 14.2. The wide is attached only to this association, so it cannot repair or disturb the separately scoped Sienna interval still awaiting its archive signature.

Ruth Elms stays longer. Her bat supplies three before Mira Vale bowls her. The team state at that dismissal is preserved by the fall clerk, while the over sheet carrying the legal-ball marker is temporarily in another room. Priya Cove arrives for the last association.

A working partnership note remains provisional when a replay of Ruth’s first scoring stroke appears afterward. The replay carries the same event fingerprint, but this local page does not contain Emilia’s component or the interval’s extras card. Its status must be settled against remote ledgers before the row becomes authoritative, and the partnership’s table value is never voiced.

A separate chase-extras audit checks the non-batter events by signature without assembling a category list. It confirms that the Ruth interval carries wide card CW164, while the Lara, Faye and final associations contain none. The opening card and the Sienna, Bella and Celeste cards remain where they first appeared. An old wide clip is still present on the television pass as a plausible rival.

The wide clerk compares the dispersed cards with legal-ball transitions. The inherited Sienna image and the old television clip resolve to already logged signatures rather than fresh deliveries; the cards carrying new transitions remain valid. The clerk does not collect their values into a local tally. With that identity settled, the delayed Sienna partnership row receives its signature because its batter and extras scopes now share one boundary event. No wides total, partnership value or extras total is stated.

Priya begins the final association with a boundary whose square-leg angle is replayed immediately. Her full contribution in the stand consists of that boundary and a single, while Emilia supplies one and the interval has no extras. Television initially advances the team ledger for both camera angles.

The scorer matches the two boundary pictures by frame fingerprint, striker, field map and timestamp. The second image is evidence of the first shot, not another delivery. The inflated television state remains visible for several seconds, while the paper roll-forward from Ruth’s dismissal excludes the duplicate.

The over sheet returns and places Ruth’s dismissal at 16.5. The fall clerk independently records Ruth after eight prior wickets. Neither source repeats the score, and neither resolves the eventual last-wicket state alone. A batter-component card returned in the same archive box records Emilia’s work during the Ruth interval as three completed pairs, without reproducing Ruth’s share or the extras event.

At 17.4 Emilia drives Mira and Jade takes the catch. A parser temporarily credits Jade because it follows the catcher name, but the delivery signature belongs to Mira’s spell. The batting dismissal, team wicket and partnership end remain valid while the bowling ownership is repaired.

Priya is not out and no further ball is delivered. The fall clerk marks Emilia as the wicket after Ruth, the over sheet supplies 17.4, and the scorer rolls forward the team state using the genuine boundary only, Priya’s single, Emilia’s single and no extras. The composite state is recoverable without any source printing it whole.

The chase reconciliation uses two independent conservation checks. The batter ledger comprises Emilia’s distributed innings, Maris’s two, Lara’s one, Sienna’s four, Celeste’s one, Ruth’s three and Priya’s five, with four batters on zero. The extras ledger is exhaustive after wide deduplication. The ten dismissal identities also reconcile with the run-out rule and the distinct delivery signatures already dispersed through the chase, but this closing audit does not enumerate any bowler’s allocation. The same audit accepts the Ruth–Emilia component note after matching its replay fingerprint and its two wicket-boundary identifiers.

The archive closes with Meadowridge confirmed as winner and Jade as player of the match. The production team preserves every provisional strip, replay fingerprint and authority decision alongside the final ledgers. A later annotator can therefore reconstruct the requested cells from shared events rather than from a summary sentence.

### Brookhaven synchronization memorandum

Brookhaven's synchronization memorandum was written because the venue board and the ingestion service produced two internally balanced first-innings cards. The discrepancy is not confined to one field. It passes through Elena's opening attribution, the leg-bye class, the duplicated free-hit frame, the Rowan-Nora partnership and the fourth-wicket boundary. The memorandum keeps both reconstructions open while it traces their event signatures.

The opening pad picture is the first fork. One reconstruction attaches the visible run to Elena because she is striker; the other follows the delayed square-leg signal and puts the event outside the bat. Mira's opening contribution and the partnership boundary are independently fixed, but the local television ribbon can be balanced under either ownership choice. The delayed card has the same delivery fingerprint as the ringed pad event and a different fingerprint from Elena's cover drive.

The long Rowan-Nora association contains a second fork. The free-hit setup was written twice by the ingestion service. One worksheet row has the live legal-transition signature and one has only the copied picture. A provisional branch preserves both rows, raises the non-batter stream and shifts the boundary at Rowan's dismissal. Another branch collapses the copied frame. Nora's personal feed also carries the disputed item, so adjusting only partnership extras creates a second inconsistency rather than resolving the first.

The wicket partition must be solved with the same component. Aila's early delivery signatures establish two genuine transitions, while the Mira lbw is owned by Nia's end log. Celeste's line contains delivered dismissals separated by Lena's run out, which remains a team wicket without a bowling credit. A production summary can swap one ownership edge and still show eight fallen batters; it fails only when delivery owners and the non-bowler dismissal are checked together.

The chase has its own connected fork. A cached Sinclair caption is attached to Aila's old stump clip, while later live Sinclair deliveries dismiss different batters. Separately, the Sienna association carries a copied wide picture and Emilia's provisional batter feed carries the same unit. The Ruth association later receives another replay with an old fingerprint. A row-by-row repair can make Jade's bowling line, Emilia's innings line or either partnership look plausible, but not all of them against the accepted wide signatures and wicket transitions.

No final number is supplied in the memorandum. It records that the chase-wide signatures are distributed across the opening, Sienna, Celeste, Ruth and closing passages; only packets with an umpire call and a legal-transition position enter the class. The Sienna and Ruth replay packets are retained as evidence links, not scoring nodes. Emilia's component therefore has to be reconstructed across nonadjacent partnerships rather than copied from either television profile.

### signature arbitration ruling

The arbitration ruling states three tests. First, a graphics row without a legal transition cannot survive as a new delivery. Second, a run-out changes batter, partnership and team-wicket state but cannot be reassigned to a bowler. Third, the same event fingerprint cannot occupy both a batter component and an extras component. The ruling identifies the opening pad card, the free-hit mirror pair and the stale Sinclair caption by signature but does not print their numeric effects.

The first-innings candidate must satisfy batter-plus-extras conservation, the sealed Rowan dismissal boundary, eight distinct fallen-batter events and the bowling-credit partition. Each test alone permits the venue branch or the ingestion branch after a compensating local edit. Their intersection does not. The chase candidate must satisfy the accepted wide-signature set, the Sienna and Ruth partnership boundaries, Emilia's cross-partnership ownership and the dismissal-owner registry. The signed registry stores only the surviving event edges.

| Innings | Table | Row | Column | Value |
| --- | --- | --- | --- | --- |
| I1 | Batting | Elena Cross (wk) | R |  |
| I1 | Batting | Nora Finch (c) | R |  |
| I2 | Batting | Emilia Shaw (c) | R |  |
| I1 | Bowling | Aila Rowan | W |  |
| I1 | Bowling | Celeste Reed | W |  |
| I2 | Bowling | Jade Sinclair | W |  |
| I1 | Innings Summary | Leg Byes | Value |  |
| I1 | Innings Summary | No Balls | Value |  |
| I2 | Innings Summary | Wides | Value |  |
| I1 | Partnerships | Rowan Hayes & Nora Finch | Runs |  |
| I2 | Partnerships | Sienna Park & Emilia Shaw | Runs |  |
| I2 | Partnerships | Ruth Elms & Emilia Shaw | Runs |  |

## match_0106.R4C

Resolve the accepted match state jointly. Two locally coherent event assignments may survive inside individual documents. Use delivery identity, explicit source authority, legal-ball state, dismissal ownership and cross-table conservation; do not repair requested rows independently.

| Innings | Table | Row | Column | Value |
| --- | --- | --- | --- | --- |
| I1 | Innings Summary | Total | Value |  |
| I2 | Innings Summary | Total | Value |  |
| I1 | Fall of Wickets | 4 | At |  |
| I2 | Fall of Wickets | 10 | At |  |

## match_0178.R4S

Resolve the accepted match state jointly. Two locally coherent event assignments may survive inside individual documents. Use delivery identity, explicit source authority, legal-ball state, dismissal ownership and cross-table conservation; do not repair requested rows independently.

### match_0178 continuous broadcast archive

The archive opens on a blustery afternoon at South Meridian Institute Ground, where Shoreline Rangers bat first and the production truck is running three score feeds at once. The television ribbon follows a wireless scorer, the radio booth keeps a handwritten sheet, and the official terminal accepts only messages carrying a delivery signature. Finn Archer begins fluently while Leo Marsh plays himself in. During the opening exchange, a glance is keyed to Finn by the television operator, although the umpire is screened by the striker. That key survives on the wagon-wheel graphic. The radio caller notes that the signal is obscured and declines to settle whether the contact was bat or pad.

Leo starts finding gaps after the first drinks runner has left the field. Two completed byes are visible in the keeper’s notebook, while three wides are scattered across Tyler Quinn’s opening spell. Finn’s share of the stand appears as forty on the live ribbon; Leo’s settled share is eighteen. A separate stand card contains five extras, but it is time-stamped before the contact query is examined. The team state at Leo’s dismissal is recorded by the official terminal as sixty-two for the first wicket. Aiden Scott takes the catch from Zane Cooper, and both radio and television attach the same delivery signature to that departure.

The replay director shows Leo’s catch twice, once from long-on and once from behind the bowler. The image classifier opens two clips, yet the official event record has the same striker, bowler, over position and wicket state on each. Rory Blake then blocks one ball and is bowled by Zane on the next without the score moving. His dismissal is a different signature, despite using the same bowler and appearing in the same montage. The radio sheet has Zane associated with both batters. A cached television counter briefly treats the second view of Leo’s catch as another wicket and carries that mistake into the next graphic.

Miles Carter joins Finn after Rory’s scoreless visit. The score boundary remains the state recorded after Leo because nothing came from Rory’s two balls. Finn drives through cover, Miles works the leg side, and five runs not credited to either batter are retained on the partnership strip. A provisional component card gives Finn thirty-six and Miles thirty-seven. It is not a completed partnership record: the boundary camera has marked a running event near the later dismissal for inspection, and neither card says on which side of the wicket that event belongs. The television total remains plausible, since moving the event across the boundary would not alter the innings aggregate.

The same delivery package later appears in a highlights queue under the label “Miles caught.” That caption refers to Miles Carter, the batter, rather than Miles Benton, the bowler who will appear elsewhere in the innings. Julian Vale is the catcher and Aiden Scott delivered the ball. The official terminal closes Carter’s batting event with those three identities. Its partnership message references the boundary marker but does not publish either batter’s revised share. Finn continues with Dylan Vale, who makes four during their brief overlap. The stand ends when Arin Wells catches Finn from Benton; two extras crossed during that short association.

At the start of Dylan’s next partnership, Connor Wells settles into defence while the television cache keeps Finn’s old contribution tile in a corner. Dylan is provisionally assigned fourteen during this association. A low side-on view of one hurried single is held for the umpire liaison because the ball may have brushed the pad. Connor’s eventual dismissal comes from Zane, who beats him with a straight ball. A lower-third retained from Zane’s spell also contains two accepted wides, without an innings-wide aggregate. The wicket’s batter identity, partnership boundary and over phase distinguish it from Rory’s similar-looking event.

The scoring liaison now resolves the opening glance. Rather than publishing a batter tally, the liaison sends the original delivery signature with the umpire’s leg-bye signal. The official terminal transfers that scoring unit from Finn’s personal event to the extras family while preserving the opening stand and team states. The old wagon wheel remains available as an archive image and still shows the live operator’s allocation. A second contact query from later in the innings is reviewed at the same time, but the signature belongs to Dylan and Connor, not Finn and Leo. The archive therefore contains similar-looking disputes whose records resolve through different scoring rules.

Dylan’s reviewed single reaches the archive as a live scoring record and an automatic packet carrying the same running signature. The side-on frame does not yet settle whether the visible contact should govern either packet. The terminal marks the records as linked and sends them to a later authority queue. Connor’s own twelve is already closed on the radio sheet, and one cached partnership strip still shows Dylan’s provisional figure. Both a bat-event version and a pad-event version remain locally plausible until the source hierarchy and wicket boundary are revisited.

Evan Price follows Connor. Dylan’s contribution in that passage first appears as ten, while Evan’s settled contribution is six. At Evan’s dismissal, Aiden Scott is the bowler and the ball hits the stumps. A transition packet containing the final running event reaches television before the official scorer attaches the wicket boundary. Noah Grant is already approaching in the wide shot. A fielding-spell recap elsewhere shows Blake Morgan with no wides and Evan Carter with two accepted calls; neither belongs to this batting transition. The archive desk flags the running packet without declaring which association will retain it.

Noah and Dylan produce the longest late recovery. Dylan’s accepted contribution in this association is thirty-seven and Noah’s is twenty-four, with seven extras appearing in the stand event stream. Miles Benton has Dylan caught by Isaac Vale. The television cuts immediately to Finn’s earlier catch, then to Noah’s later dismissal, so three Benton events sit together even though they occurred in separate partnerships. Each carries a distinct batter and delivery signature. The radio book also has Aaron Miles bowled by Benton between Dylan and Noah, while the producer’s montage initially omits that shorter event because it lacks a catch image.

An official boundary message eventually attaches the disputed transition run to Noah’s association. The message identifies Evan’s dismissal as the boundary and references the running event, but it does not quote Dylan’s completed innings figure. The cached strip is retained for broadcast chronology. At roughly the same time, a second camera angle of Dylan’s catch is ingested as a fresh clip; the archive registry links it to the existing Benton event. A separate spell graphic assigns Benton three accepted wides, information that has no authority over the duplicate camera view.

Aaron Miles is bowled by Benton in the lower order, and Noah is later caught from Benton with Arin Wells completing the chance. Their signatures enter the registry at different partnership states and are not summarized with earlier credits. The surname-only Carter caption is held outside the ledger pending role resolution, while Logan Shaw’s final bowled event carries Cameron Ellis’s delivery identifier. The radio booth places several Miles surnames on one hurried page, making that page unsafe without event ownership. The terminal accepts or rejects individual signatures but withholds Benton’s closed bowling panel.

The first-innings wides channel is meanwhile noisy. During Aiden Scott’s spell, the radio book contains three umpire-called wides. A graphics reconnect then emits another packet with the same ball signature, unchanged striker state and no fresh signal. The television ribbon accepts both and rises to a locally plausible state; the wireless scorer marks the pair for comparison but does not yet declare which record survives. Other bowlers’ components are absent from this screen, so neither the ribbon nor the radio page can close the innings-wide category here.

During the final overs Toby Reed counterattacks, Logan Shaw is bowled by Cameron, and the last legal-ball state is preserved as forty-seven completed overs plus two further valid deliveries. Cameron’s spell graphic carries four accepted wides, while the unresolved refresh remains on another feed. A delayed liaison message now confirms bat on Dylan’s Connor single; the delivery registry preserves the live record and rejects its automatic copy. The official batting ledger gives the nine non-target Shoreline batters one hundred twenty-four, with two byes and a no-ball settled separately, but no completed innings state is read aloud.

At the innings break the boundary camera’s decision on the Finn-Carter stand is released. The running event occurred after Carter’s dismissal signature had closed the partnership, so it belongs to the next association. The official terminal rejects that event from both provisional batter components attached to the completed stand. Finn’s and Carter’s accepted shares require the event identity and remote score boundaries. On a different console, the wireless scorer preserves Aiden’s original wide signature and retires the reconnect copy. Neither decision publishes a completed stand or innings-wide total.

The innings-review editor now tests whether every fallen-batter record has one owner. Alternate camera angles are joined to their original delivery signatures before any bowler partition is closed. A surname-only “Miles” caption remains quarantined until batter, bowler and catcher roles are recovered from the live call. The editor checks the accepted registry against the ten distinct departures, but the review screen displays neither Zane’s nor Benton’s completed column. That global partition can expose an omitted or repeated event without supplying a local numerical verdict.

Meridian Strikers begin the chase with Arin Wells taking the only scoring run before Isaac Vale is leg before to Caleb Turner. The official terminal closes that first-wicket state at the fourth legal ball. Two preview clips use the same signature, so only the live event enters Caleb’s ledger. Evan Carter joins Arin. The radio sheet gives Evan seven for their partnership, while the live stand-extras box opens at seven. Arin’s component is hidden by a weather banner. The feed remains provisional because one of those extras came from an automatic scoring packet that may duplicate an umpire call.

Caleb’s full spell contains six accepted wides, spread across several overs rather than concentrated around Isaac’s dismissal. Finn Archer later bowls a short spell with one, and Logan Shaw’s spell contains none. These bowling figures appear during interviews and are not adjacent to the chase extras panel. In the Carter-Arin stand, the suspicious packet has the same delivery identifier, striker and non-striker state as a wide already called live. The official scorer quarantines it, but the television stand card continues to carry both entries. Team, partnership and Arin’s cached attribution all remain locally plausible until the authoritative packet decision arrives.

Evan is bowled by Logan Shaw. The official wicket event is accepted at the second legal delivery after six completed overs, and the previous first-wicket state remains in terminal history. The television ribbon momentarily shows the chase at twenty-eight for two because it carries the duplicate packet. A cached player tile, issued from that same feed, assigns Arin fourteen within the Carter window. The radio caller has a lower team state but cannot explain the difference live. The terminal references the suspect signature in a correction queue rather than printing either a settled partnership or personal total.

Tyler and Arin rotate strike through a cautious passage. Arin’s accepted contribution during this association is ten, while two extras are tied to legal-ball and wide records elsewhere. Tyler’s provisional personal tile says seven. One sweep hits pad before travelling into the outfield; the umpire’s signal is blocked by the non-striker. Connor Reed later bowls Arin, but a wide earlier in that over means the wall-clock sequence cannot be used as the legal-ball count. The television wicket strip includes the earlier duplicate from the Carter stand and is therefore a provisional score state.

The delivery authority resolves the Carter-Arin duplication by rejecting the automatic packet and preserving the live wide call. That single event decision propagates through the team stream, the partnership extras channel and Arin’s personal attribution cache; no terminal message states any of their final values. Evan’s seven remains untouched. A stand snapshot from before the decision continues circulating in a replay package. The authoritative second-wicket state, the event components and the rejected packet together are required to recover the completed Carter-Arin association rather than choosing between the radio and television cards by recency.

A side-on replay later settles Tyler’s sweep as leg byes. The authority references the Arin partnership delivery, not the superficially similar first-innings pad events. Tyler’s provisional share changes ledger, while the team and partnership values do not. After Arin’s dismissal, Tyler adds seven with Aiden Scott before Dylan Vale catches him from Aaron Miles. The archive then replays the sweep beside Tyler’s catch, but one is a scoring-attribution event and the other a dismissal. Their shared batter must not merge them. Tyler takes no part in another partnership after the catch.

Connor’s over record supplies the legal-ball detail for Arin’s dismissal: eleven overs were complete, a wide interrupted the sequence, and the wicket delivery is the fourth legitimate ball thereafter. The preceding wicket state is Evan’s authoritative boundary, and the Tyler-Arin event stream supplies the intervening score movement. The provisional post-wicket strip is one unit too high because of the Carter-stand packet that has since been rejected. The official terminal accepts Connor as bowler and Arin as the third dismissed batter without publishing a formatted fall-of-wicket line.

Blake Morgan is bowled by Aaron Miles after Tyler’s catch. A big-screen replay of Tyler’s dismissal follows immediately, and an automated highlight counter briefly groups both clips as fresh Aaron events. Their delivery signatures separate the new Blake wicket from the old Tyler view. Julian Vale is then bowled by Connor Reed, and Aiden Scott is caught from Tyler Quinn’s bowling. These intervening dismissals matter because the late Aaron sequence is not continuous. A montage sorted by bowler surname is useful evidence only after every batter, over phase and dismissal mode has been resolved.

The chase-wide ledger continues to arrive in fragments. Connor’s spell contains two accepted wides and Aaron’s contains two. Tyler’s later spell has one. A legal dot following a graphics reconnect is nevertheless entered as a wide on the television ribbon because the automatic parser sees the bowler reset his mark. The delivery authority has the ball recorded as valid and scoreless, with no umpire signal. It places that packet in quarantine. The team strip and a stand-extras panel retain the television version, while the bowling cards do not support it.

Leo Foster survives several overs before Aaron Miles bowls him. Slow motion from behind the arm is stored as another clip with the same batter, bowler and delivery position. The highlight counter provisionally treats the view as an additional wicket. Cameron Ellis later advances to Aaron’s flighted ball and is stumped by Owen Hayes. The batting and partnership terminals accept Cameron’s departure immediately, yet a bowling-cache interruption means Aaron’s personal panel does not receive that event at first. Thus one authentic dismissal is absent while one replay duplicate is present, producing a plausible but structurally wrong local ledger.

Aiden’s dismissal and Leo’s fall define a later chase boundary. Between them, the official team record moves through a small Leo-Cameron partnership whose extras include legitimate wides. The director repeatedly uses the same Leo slow motion while commentators discuss Aaron’s control. The registry matches that view to the live delivery by batter, bowler and over position, then retires the replay packet. Aaron’s cache still lacks a different late event, so the locally displayed wicket state remains plausible but unclosed.

The delivery authority now rejects the television’s legal-dot wide. It identifies the packet by ball signature and the absence of an umpire signal, without displaying the revised chase-wide category. Caleb, Finn, Logan, Connor, Aaron and Tyler have already supplied their accepted spell components on separate graphics. The chase also contains no byes, one no-ball from Connor, and pad-contact units whose accepted leg-bye record consists of three events. Those categories can be reconciled against the team ledger, but no single card presents their aggregate.

At the scorer’s desk, Arin’s stale player profile and Aaron’s interrupted bowling cache arrive in the same archive batch. The profile predates the Carter-window packet decision, while the authoritative attribution ledger is versioned after Evan’s wicket review. Neither screen repeats Arin’s other partnership components. On a separate rules channel, Cameron’s already accepted stumping signature is propagated into the bowler-credit cache because the delivery was legal and Aaron was the bowler. The message repairs event ownership without displaying either player’s completed row.

Dylan’s archive row receives a similar audit. His four with Finn is closed by Finn’s catch, his Connor component begins from the live fourteen but carries the separate packet ruling, his Evan component begins from ten but crosses the reviewed wicket boundary, and his Noah contribution is the settled thirty-seven. The two rulings concern different deliveries and different ledger families, so neither can be applied twice. No graphic combines the four accepted components. The result must also remain compatible with the first-innings batter aggregate and the distant partnership boundaries.

Finn’s audit reaches across the opening, Rory, Carter and Dylan windows. The opening live component carries the pad decision, Rory’s scoreless stay contributes nothing, and the Carter window carries the boundary-camera decision. Finn records no scoring event after Carter’s dismissal before his own wicket; Dylan’s four and the two extras account for that short stand. The old wagon wheel and provisional Carter card remain tempting because each is individually coherent. Only the official delivery identities, plus the first-innings conservation ledger, determine which versions survive together.

The chase closes with Miles Benton bowled by Tyler Quinn after Zane Cooper has joined him. The legal-ball archive records twenty-four full overs and four further valid deliveries. The nine non-target Meridian batters together contribute twenty-one. The accepted extras families comprise the six dispersed bowler-wide components, the three pad-contact leg-bye events, Connor’s no-ball and no byes. Arin and Tyler supply the two target batting components. These separate ledgers reconcile to the terminal’s final state, although neither commentary team reads that state aloud and the television ribbon is removed before the handshake.

For the first innings, the archive’s third-wicket composite is also recoverable without a direct caption. Rory’s wicket fixes the lower score boundary. Finn and Carter’s accepted components and the five partnership extras determine the movement before Carter is caught. The dismissal occurs after twenty-three completed overs on the fourth valid ball of the next over; an earlier wide in the spell does not advance that legal count. The cached component cards predate the boundary ruling, so they cannot be copied into the fall-of-wicket string without version control.

For the chase’s third wicket, Evan’s accepted boundary is the lower state. The Tyler-Arin association consists of Arin’s settled ten, Tyler’s attribution after the pad ruling, and two extras. Connor’s wide in the dismissal over does not consume a legal delivery, and Arin’s bowled event is the fourth valid ball after eleven completed overs. The television wicket strip still carries the rejected Carter packet. The terminal history, not that newest-looking picture, governs both the score component and over notation.

The closing archive sweep links the two innings without mixing them. First-innings pad and wide decisions update Shoreline’s batting, extras and partnership ledgers; chase decisions update Arin, Tyler, the Carter association and Meridian’s extras. Zane’s and Benton’s wickets belong only to Shoreline’s innings, while Aaron’s events belong only to the chase. Every replay remains searchable, so recency alone is useless. The accepted graph is the set of delivery signatures endorsed by the official terminal, checked against batter conservation, extras conservation, partnership boundaries, wicket uniqueness and legal-ball state.

### South Meridian engineering incident review

The engineering review treats the Shoreline innings as two synchronized streams rather than a sequence of independent card rows. The first stream begins with Finn's opening pad contact and continues through the Carter boundary. The second begins with Dylan's duplicated running packet and continues through the wide reconnect and the Benton-Zane ownership split. Either stream can be patched locally; the combined innings cannot accept both local patches.

The opening pad contact is visible on the striker camera, so the television branch assigns it to Finn. The umpire branch links the same delivery signature to the leg-bye signal. Because the team score advances under either interpretation, the disagreement survives the opening partnership and Rory's scoreless stay. It becomes consequential only when Finn's cross-partnership batter components, the Finn-Carter boundary and the innings extras classes are conserved together.

The Carter stand contains a second packet that the boundary camera places after Carter's dismissal signature. A venue branch keeps it within the stand because the pictures are contiguous; the event branch attaches it to the following association. Each branch can produce a coherent local partnership ribbon by choosing the matching upper boundary. Only the independently sealed third-wicket state and the delivery transition decide which boundary is permitted.

Dylan's running event creates the same kind of coupled ambiguity. The automatic packet and the live scoring record share a running signature. Keeping both shifts Dylan's innings line and the downstream team states; collapsing the mirror changes the Connor and Evan windows used to reconstruct him. The reconnect wide packet and the accepted bowler-wide cards supply a separate conservation channel, so a compensating edit to Dylan alone does not close the innings.

Bowling ownership is deliberately not summarized. A surname-only Miles caption can refer to Carter the batter, Benton the bowler or Aaron in the later chase. The registry attaches credits only when a live delivery signature, dismissed batter and incoming-batter transition agree. Alternate camera angles for the Zane and Benton dismissals remain mirror nodes. This partition is checked against ten distinct first-innings dismissals rather than a television wicket numeral.

In the chase, the Carter-Arin feed opens one live wide and one automatic packet. A player-profile branch consumes both and lowers the remaining extras needed elsewhere; the authority branch merges the packet with the live call. Tyler's later pad event then determines whether a unit stays with his bat or enters a non-batter channel. Both choices can be made to fit a short local partnership graphic, but they cannot both satisfy Arin's cross-window account, Tyler's later contribution, the accepted chase-wide signatures and the third-wicket boundary.

Aaron's bowling cache is part of that same component. Tyler and Blake have distinct live dismissal signatures, Leo's slow motion is a mirror of his live ball, and Cameron's stumping propagates a bowler credit from a legal delivery. A cache that counts the mirror but misses the stumping reaches a plausible local total. It fails the owner registry even though the numeral happens to balance. The review therefore closes event edges, not bowler rows.

### terminal constraint register

The terminal register supplies no completed scorecard. For Shoreline it preserves the legal closing position, the third-wicket event boundary, the accepted extras categories and a one-owner rule for every fallen batter. An admissible state must use one edge for each live scoring or dismissal event, may use mirror clips only as evidence, and must conserve batter and extras streams against the terminal state. Dropping any one rule leaves both engineering patches feasible.

For Meridian the register preserves the first- and second-wicket boundaries, the fourth legitimate ball of Connor's over for the third wicket, the terminal legal-ball position and the accepted source hierarchy. It requires the Carter-Arin packet, Tyler pad attribution and Aaron stumping propagation to be solved together. The player profile, television ribbon and bowling cache are provisional views; the delivery authority and terminal registry control the surviving graph.

| Innings | Table | Row | Column | Value |
| --- | --- | --- | --- | --- |
| I1 | Batting | Finn Archer | R |  |
| I1 | Batting | Dylan Vale | R |  |
| I2 | Batting | Arin Wells (wk) | R |  |
| I2 | Batting | Tyler Quinn | R |  |
| I1 | Bowling | Zane Cooper | W |  |
| I1 | Bowling | Miles Benton | W |  |
| I2 | Bowling | Aaron Miles | W |  |
| I1 | Innings Summary | Leg Byes | Value |  |
| I1 | Innings Summary | Wides | Value |  |
| I2 | Innings Summary | Wides | Value |  |
| I1 | Partnerships | Finn Archer & Miles Carter | Runs |  |
| I2 | Partnerships | Evan Carter & Arin Wells | Runs |  |

## match_0178.R4C

Resolve the accepted match state jointly. Two locally coherent event assignments may survive inside individual documents. Use delivery identity, explicit source authority, legal-ball state, dismissal ownership and cross-table conservation; do not repair requested rows independently.

| Innings | Table | Row | Column | Value |
| --- | --- | --- | --- | --- |
| I1 | Innings Summary | Total | Value |  |
| I2 | Innings Summary | Total | Value |  |
| I1 | Fall of Wickets | 3 | At |  |
| I2 | Fall of Wickets | 3 | At |  |

